"""Download and cache the current FYERS NSE capital-market symbol master."""
from __future__ import annotations
import io
from pathlib import Path
from typing import List
import pandas as pd
import requests
from config import FYERS_SYMBOL_MASTER_URL

CACHE = Path(__file__).resolve().parent / "data_store" / "nse_equity_symbols.csv"
COLS = ["fytoken","name","instrument_type","lot_size","tick_size","isin","trading_session","last_update","expiry_date","symbol","exchange","segment","scrip_code","short_symbol","strike","option_type","extra"]

def load_nse_equities(refresh: bool = False, timeout: int = 30) -> List[str]:
    if not refresh and CACHE.exists():
        df = pd.read_csv(CACHE)
        if "symbol" in df.columns and len(df): return df.symbol.astype(str).tolist()
    r = requests.get(FYERS_SYMBOL_MASTER_URL, timeout=timeout, headers={"User-Agent":"Mozilla/5.0"})
    r.raise_for_status()
    raw = pd.read_csv(io.BytesIO(r.content), header=None, dtype=str)
    # FYERS symbol master is a headerless CSV and its columns can evolve. Symbol is column 9 in the documented layout.
    if raw.shape[1] < 10: raise RuntimeError(f"Unexpected FYERS symbol master columns: {raw.shape[1]}")
    raw.columns = [COLS[i] if i < len(COLS) else f"col_{i}" for i in range(raw.shape[1])]
    raw["symbol"] = raw["symbol"].astype(str).str.strip()
    df = raw[(raw["symbol"].str.startswith("NSE:")) & (raw["symbol"].str.endswith("-EQ"))].copy()
    df = df[["symbol"]].drop_duplicates().sort_values("symbol")
    if df.empty: raise RuntimeError("No NSE equity symbols found in FYERS symbol master")
    CACHE.parent.mkdir(parents=True, exist_ok=True); df.to_csv(CACHE, index=False)
    return df.symbol.tolist()
