"""Deterministic simulated streaming provider for demonstrations and testing."""
from __future__ import annotations
import random, time
from typing import Dict, List, Optional
import numpy as np
from config import MOCK_SYMBOLS, cfg
from utils.etq_tracker import Tick, MarketState, WindowStats
from utils.indicators import RunningSMMA

class MockProvider:
    def __init__(self, symbols: Optional[List[str]] = None, seed: int = 42):
        self.symbols = symbols or MOCK_SYMBOLS
        random.seed(seed); np.random.seed(seed)
        self.state = MarketState(cfg.windows)
        self.running_smma_fast = {}; self.running_smma_slow = {}
        self.base_prices = {}; self.day_volume = {}
        self._init_symbols()

    def _init_symbols(self):
        for sym in self.symbols:
            price = random.uniform(35, 480)
            self.base_prices[sym] = price; self.day_volume[sym] = random.randint(500_000, 5_000_000)
            self.running_smma_fast[sym] = RunningSMMA(cfg.smma_fast)
            self.running_smma_slow[sym] = RunningSMMA(cfg.smma_slow)
            for _ in range(cfg.smma_slow + 20):
                price *= 1 + random.gauss(0, 0.0015)
                self.running_smma_fast[sym].update(price); self.running_smma_slow[sym].update(price)
            self.base_prices[sym] = price

    def generate_tick(self, symbol: str) -> Tick:
        now = time.time(); price = self.base_prices[symbol]
        change = random.gauss(0, 0.0015) * price
        if random.random() < 0.03: change += random.choice([-1, 1]) * random.uniform(0.005, 0.02) * price
        new_price = max(30.5, min(499.0, price + change)); self.base_prices[symbol] = new_price
        ltq = random.randint(50_000, 400_000) if random.random() < 0.08 else random.randint(50, 5_000)
        self.day_volume[symbol] += ltq
        spread = max(0.05, new_price * 0.0008)
        bid, ask = round(new_price - spread/2, 2), round(new_price + spread/2, 2)
        bid_qty, ask_qty = random.randint(800_000, 3_500_000), random.randint(800_000, 3_500_000)
        if random.random() < 0.15: bid_qty, ask_qty = random.randint(100_000, 900_000), random.randint(100_000, 900_000)
        sf = self.running_smma_fast[symbol].update(new_price); ss = self.running_smma_slow[symbol].update(new_price)
        tick = Tick(now, round(new_price,2), ltq, bid, ask, bid_qty, ask_qty, self.day_volume[symbol])
        tr = self.state.get_or_create(symbol)
        tr.smma_fast, tr.smma_slow = sf, ss
        self.state.update(symbol, tick)
        return tick

    def snapshot(self):
        rows=[]; now=time.time()
        for sym in self.symbols:
            tick=self.generate_tick(sym); tr=self.state.trackers[sym]
            # Crossover detection happens BEFORE screening, so crossings are not silently lost.
            curr_diff = (tr.smma_fast or 0) - (tr.smma_slow or 0)
            prev_diff = getattr(tr, "prev_diff", None)
            signal = None
            if prev_diff is not None:
                if prev_diff <= 0 < curr_diff: signal = "BUY"
                elif prev_diff >= 0 > curr_diff: signal = "SELL"
            tr.prev_diff = curr_diff
            if signal:
                tr.last_signal, tr.signal_ts, tr.signal_ltp = signal, now, tick.ltp
                tr.crossover_count = getattr(tr, "crossover_count", 0) + 1
            if not (cfg.ltp_min <= tick.ltp <= cfg.ltp_max): continue
            if not (tick.bid_qty > cfg.min_bid and tick.ask_qty > cfg.min_ask): continue
            wins=tr.get_all_windows(now)
            rows.append({
                "symbol":sym.replace("NSE:","").replace("-EQ",""), "ltp":tick.ltp, "bid":tick.bid,
                "bid_qty":tick.bid_qty, "ask":tick.ask, "ask_qty":tick.ask_qty,
                "smma_20":round(tr.smma_fast,2) if tr.smma_fast else None,
                "smma_120":round(tr.smma_slow,2) if tr.smma_slow else None,
                "etq_5":wins.get(5,WindowStats()).etq, "etq_20":wins.get(20,WindowStats()).etq,
                "etq_60":wins.get(60,WindowStats()).etq, "avg_ltp_20":wins.get(20,WindowStats()).avg_ltp,
                "avg_ltp_60":wins.get(60,WindowStats()).avg_ltp, "ltq":tick.ltq, "volume":tick.volume,
                "ltq_ratio_2_5":round(tr.ltq_ratio(2,5),3), "signal":signal,
                "_tracker":tr, "_tick":tick,
            })
        return rows
