"""Live FYERS market-data provider.

The provider uses three FYERS v3 data paths:
1) Quotes API for the full NSE-equity LTP screen (max 50 symbols/request).
2) Market Depth API for the required aggregate bid/ask quantities.
3) Data WebSocket SymbolUpdate + DepthUpdate for ongoing LTQ/LTP/order-book data.

This project is data-only and never places broker orders.
"""
from __future__ import annotations

import threading
import time
from collections import deque
from typing import Dict, Optional, Tuple

from config import FYERS_APP_ID, FYERS_ACCESS_TOKEN, cfg
from instrument_master import load_nse_equities
from utils.etq_tracker import Tick, MarketState
from utils.indicators import RunningSMMA

try:
    from fyers_apiv3 import fyersModel
    from fyers_apiv3.FyersWebsocket import data_ws
except Exception as exc:  # pragma: no cover
    fyersModel = None
    data_ws = None
    _IMPORT_ERROR = exc


class FyersProvider:
    """Real-time NSE screener backed by FYERS API v3."""

    # FYERS currently documents a 200 requests/minute standard API allowance.
    # Depth is a single-symbol REST endpoint, so we throttle depth requests.
    # Keep comfortably below FYERS Standard's documented 200 requests/minute.
    # This is intentionally conservative so a previous scan cannot immediately
    # push the next scan over the broker limit.
    DEPTH_REQUESTS_PER_MINUTE = 60
    DEPTH_MIN_INTERVAL = 60.0 / DEPTH_REQUESTS_PER_MINUTE
    DEPTH_CACHE_SECONDS = 30.0
    DEPTH_BATCH_PER_SCAN = 5
    DEPTH_RECHECK_SECONDS = 300.0

    def __init__(self, universe=None):
        if fyersModel is None or data_ws is None:
            raise RuntimeError(f"Install fyers-apiv3: {_IMPORT_ERROR}")
        if not FYERS_APP_ID or not FYERS_ACCESS_TOKEN:
            raise RuntimeError("Set FYERS_APP_ID and FYERS_ACCESS_TOKEN in .env")

        self.token = f"{FYERS_APP_ID}:{FYERS_ACCESS_TOKEN}"
        self.fyers = fyersModel.FyersModel(
            client_id=FYERS_APP_ID,
            token=FYERS_ACCESS_TOKEN,
            is_async=False,
            log_path="",
        )
        self.universe = universe
        self.candidates = []
        self.price_candidates = []
        self.state = MarketState(cfg.windows)
        self.fast: Dict[str, RunningSMMA] = {}
        self.slow: Dict[str, RunningSMMA] = {}
        self.latest: Dict[str, dict] = {}
        self.depth: Dict[str, dict] = {}
        self.depth_cache: Dict[str, Tuple[float, dict]] = {}
        self.prev_diff: Dict[str, float] = {}
        self.ws = None
        self.started = False
        self.ws_connected = False
        self.last_error = ""
        self.last_scan = 0.0
        self.last_depth_scan = 0.0
        self.last_depth_requests = 0
        self.crossover_events = []
        self._last_depth_request = 0.0
        self._depth_queue = deque()
        self._depth_checked = {}
        self._depth_failed = {}
        self._depth_scan_total = 0
        self._depth_scan_checked = 0
        self._depth_scan_complete = False
        self._depth_worker = None
        self._stop_event = threading.Event()
        self._lock = threading.RLock()
        self._subscribed_symbols = set()

    def load_universe(self, refresh=False):
        if self.universe is None or refresh:
            self.universe = load_nse_equities(refresh=refresh)
        return self.universe

    @staticmethod
    def num(d, *keys, default=0.0):
        for key in keys:
            try:
                if isinstance(d, dict) and d.get(key) is not None:
                    return float(d[key])
            except (TypeError, ValueError):
                pass
        return float(default)

    @classmethod
    def _depth_fields(cls, raw: dict) -> dict:
        """Normalize the FYERS depth response into best bid/ask + total quantities."""
        if not isinstance(raw, dict):
            return {}

        # REST responses are normally under d. Some SDK/server revisions wrap
        # the symbol one level deeper, so unwrap conservatively.
        data = raw.get("d", raw)
        if isinstance(data, dict) and len(data) == 1:
            only = next(iter(data.values()))
            if isinstance(only, dict) and any(k in only for k in ("bids", "ask", "asks", "totalbuyqty", "totalsellqty")):
                data = only

        if not isinstance(data, dict):
            return {}

        bids = data.get("bids") or data.get("bid") or []
        asks = data.get("ask") or data.get("asks") or []
        if isinstance(bids, dict):
            bids = [bids]
        if isinstance(asks, dict):
            asks = [asks]

        best_bid = 0.0
        best_bid_qty = 0
        best_ask = 0.0
        best_ask_qty = 0

        if isinstance(bids, list) and bids:
            b0 = bids[0] if isinstance(bids[0], dict) else {}
            best_bid = cls.num(b0, "price", "bid", "bid_price")
            best_bid_qty = int(cls.num(b0, "volume", "qty", "quantity", "bid_qty"))
        if isinstance(asks, list) and asks:
            a0 = asks[0] if isinstance(asks[0], dict) else {}
            best_ask = cls.num(a0, "price", "ask", "ask_price")
            best_ask_qty = int(cls.num(a0, "volume", "qty", "quantity", "ask_qty"))

        # Assignment liquidity filter uses the aggregate quantities available
        # in the market-depth book. Fall back to summing the returned levels if
        # the explicit totals are absent.
        total_buy = int(cls.num(data, "totalbuyqty", "total_buy_qty", "totalBuyQty"))
        total_sell = int(cls.num(data, "totalsellqty", "total_sell_qty", "totalSellQty"))
        if total_buy <= 0 and isinstance(bids, list):
            total_buy = sum(int(cls.num(x, "volume", "qty", "quantity")) for x in bids if isinstance(x, dict))
        if total_sell <= 0 and isinstance(asks, list):
            total_sell = sum(int(cls.num(x, "volume", "qty", "quantity")) for x in asks if isinstance(x, dict))

        ltp = cls.num(data, "ltp", "lp")
        if best_bid <= 0:
            best_bid = cls.num(data, "bid", "bid_price")
        if best_ask <= 0:
            best_ask = cls.num(data, "ask", "ask_price")
        if best_bid_qty <= 0:
            best_bid_qty = int(cls.num(data, "bid_size", "bid_qty", "bid_quantity"))
        if best_ask_qty <= 0:
            best_ask_qty = int(cls.num(data, "ask_size", "ask_qty", "ask_quantity"))

        return {
            "ltp": ltp,
            "bid": best_bid,
            "bid_qty": total_buy,
            "bid_level_qty": best_bid_qty,
            "ask": best_ask,
            "ask_qty": total_sell,
            "ask_level_qty": best_ask_qty,
            "volume": int(cls.num(data, "volume", "vtt")),
            "raw": data,
        }

    def _get_depth(self, symbol: str, force=False) -> dict:
        now = time.time()
        cached = self.depth_cache.get(symbol)
        if not force and cached and now - cached[0] < self.DEPTH_CACHE_SECONDS:
            return cached[1]

        wait = self.DEPTH_MIN_INTERVAL - (now - self._last_depth_request)
        if wait > 0:
            time.sleep(wait)

        # Reserve the request timestamp before the network call so even a fast
        # error response cannot cause a burst of requests.
        self._last_depth_request = time.time()
        try:
            response = self.fyers.depth(data={"symbol": symbol, "ohlcv_flag": "1"})
            self.last_depth_requests += 1
            if isinstance(response, dict) and response.get("s") == "error":
                msg = str(response.get("message", response))
                self.last_error = f"Depth API error for {symbol}: {msg}"
                return {}
            parsed = self._depth_fields(response)
            if parsed:
                self.depth_cache[symbol] = (time.time(), parsed)
                self.depth[symbol] = parsed
            return parsed
        except Exception as exc:
            self.last_error = f"Depth API error for {symbol}: {exc}"
            return {}

    def _price_screen(self):
        """Refresh the full NSE price screen. Quotes are batched 50/request."""
        symbols = self.load_universe()
        price_candidates = []
        scanned = 0
        self.last_error = ""

        for i in range(0, len(symbols), 50):
            batch = symbols[i : i + 50]
            scanned += len(batch)
            try:
                resp = self.fyers.quotes(data={"symbols": ",".join(batch)})
                for item in resp.get("d", []) if isinstance(resp, dict) else []:
                    v = item.get("v", item) if isinstance(item, dict) else {}
                    sym = item.get("n") or item.get("symbol") or v.get("symbol")
                    ltp = self.num(v, "lp", "ltp")
                    if sym and cfg.ltp_min <= ltp <= cfg.ltp_max:
                        price_candidates.append(sym)
                    if sym and ltp > 0:
                        self._seed_quote(sym, v)
            except Exception as exc:
                self.last_error = f"Quote batch error: {exc}"

        self.price_candidates = sorted(set(price_candidates))
        return scanned

    def _queue_depth_scan(self, force=False):
        """Queue price-qualified symbols for throttled depth screening.

        High-volume names are checked first so the live dashboard can become
        useful quickly, while the complete LTP-qualified universe remains in
        the queue and is eventually checked.
        """
        now = time.time()
        fresh = []
        for sym in self.price_candidates:
            checked_at = self._depth_checked.get(sym, 0)
            failed_at = self._depth_failed.get(sym, 0)
            if force or (now - checked_at >= self.DEPTH_RECHECK_SECONDS) or (failed_at and now - failed_at >= self.DEPTH_RECHECK_SECONDS):
                fresh.append(sym)

        # Prioritize symbols with the largest reported daily volume.
        fresh.sort(
            key=lambda x: self.num(self.latest.get(x, {}), "volume", "vtt", "vol_traded_today"),
            reverse=True,
        )
        self._depth_queue = deque(fresh)
        self._depth_scan_total = len(fresh)
        self._depth_scan_checked = 0
        self._depth_scan_complete = not fresh
        self.last_depth_scan = now

    def _process_depth_batch(self, limit=None):
        """Perform a bounded number of depth calls, never exceeding the rate limit."""
        if limit is None:
            limit = self.DEPTH_BATCH_PER_SCAN

        processed = 0
        while self._depth_queue and processed < limit and not self._stop_event.is_set():
            sym = self._depth_queue.popleft()
            d = self._get_depth(sym)
            now = time.time()
            if d:
                self._depth_checked[sym] = now
                self._depth_failed.pop(sym, None)
                ltp = d.get("ltp") or self.latest.get(sym, {}).get("lp", 0)
                if (
                    cfg.ltp_min <= ltp <= cfg.ltp_max
                    and d.get("bid_qty", 0) > cfg.min_bid
                    and d.get("ask_qty", 0) > cfg.min_ask
                ):
                    old = self.latest.get(sym, {})
                    merged = dict(old)
                    merged.update(d)
                    self.latest[sym] = merged
                    self.depth[sym] = d
                    self._seed_depth_quote(sym, d)
                    with self._lock:
                        if sym not in self.candidates:
                            self.candidates.append(sym)
                            self.candidates = sorted(self.candidates)[: cfg.max_symbols]
                else:
                    with self._lock:
                        if sym in self.candidates:
                            self.candidates.remove(sym)
            else:
                self._depth_failed[sym] = now
            processed += 1
            self._depth_scan_checked += 1

        self._depth_scan_complete = not self._depth_queue
        if self._depth_scan_complete:
            self.last_depth_scan = time.time()
        return processed

    def initial_screen(self, depth_batch=None):
        """Refresh all prices and start a throttled, resumable depth scan.

        This method deliberately does not pretend that an incomplete depth scan
        means zero qualified stocks. The dashboard reports the scan progress.
        """
        scanned = self._price_screen()
        self._queue_depth_scan(force=False)
        self._process_depth_batch(depth_batch or self.DEPTH_BATCH_PER_SCAN)
        with self._lock:
            self.last_scan = time.time()
        return list(self.candidates), scanned

    def _depth_worker_loop(self):
        """Continue depth screening in the background without blocking the UI."""
        while not self._stop_event.is_set():
            try:
                if not self._depth_queue:
                    if self._depth_scan_complete:
                        # Rebuild the queue only on the normal screening interval.
                        if time.time() - self.last_scan >= cfg.screen_interval:
                            self._price_screen()
                            self._queue_depth_scan(force=False)
                            self.last_scan = time.time()
                        else:
                            self._stop_event.wait(1.0)
                            continue
                    else:
                        self._stop_event.wait(0.5)
                        continue

                before = set(self.candidates)
                self._process_depth_batch(self.DEPTH_BATCH_PER_SCAN)
                after = set(self.candidates)

                # If the qualifying set changes, rebuild the live feed. The
                # WebSocket is capped at 5,000 by current FYERS documentation,
                # while this project intentionally limits active analysis to
                # cfg.max_symbols (200 by default).
                if after != before:
                    self._refresh_websocket()
                self._stop_event.wait(0.1)
            except Exception as exc:
                self.last_error = f"Depth worker error: {exc}"
                self._stop_event.wait(2.0)

    def _start_depth_worker(self):
        if self._depth_worker and self._depth_worker.is_alive():
            return
        self._stop_event.clear()
        self._depth_worker = threading.Thread(
            target=self._depth_worker_loop,
            name="fyers-depth-scanner",
            daemon=True,
        )
        self._depth_worker.start()

    def _refresh_websocket(self):
        """Synchronize the live subscription with the currently qualified set.

        Prefer incremental subscribe/unsubscribe so one newly qualified stock
        does not force a full reconnect. Fall back to reconnect if the SDK
        revision does not expose unsubscribe/subscribe as expected.
        """
        if not self.candidates:
            try:
                if self.ws and self._subscribed_symbols:
                    self.ws.unsubscribe(symbols=list(self._subscribed_symbols), data_type="SymbolUpdate")
                    self.ws.unsubscribe(symbols=list(self._subscribed_symbols), data_type="DepthUpdate")
            except Exception:
                pass
            self._subscribed_symbols.clear()
            return
        if self.ws is None or not self.ws_connected:
            self._connect_websocket()
            return
        target = set(self.candidates)
        add = sorted(target - self._subscribed_symbols)
        remove = sorted(self._subscribed_symbols - target)
        try:
            if remove and hasattr(self.ws, "unsubscribe"):
                self.ws.unsubscribe(symbols=remove, data_type="SymbolUpdate")
                self.ws.unsubscribe(symbols=remove, data_type="DepthUpdate")
            if add:
                self.ws.subscribe(symbols=add, data_type="SymbolUpdate")
                self.ws.subscribe(symbols=add, data_type="DepthUpdate")
            self._subscribed_symbols = target
        except Exception as exc:
            self.last_error = f"Subscription sync error: {exc}; reconnecting"
            try:
                self.ws.close_connection()
            except Exception:
                pass
            self.ws = None
            self.ws_connected = False
            self._subscribed_symbols.clear()
            self._connect_websocket()

    def _seed_quote(self, sym, v):
        ltp = self.num(v, "lp", "ltp")
        if ltp <= 0:
            return
        tick = Tick(
            time.time(),
            ltp,
            int(self.num(v, "ltq", "last_traded_qty")),
            self.num(v, "bid", "bid_price"),
            self.num(v, "ask", "ask_price"),
            0,
            0,
            int(self.num(v, "vol_traded_today", "volume", "vtt")),
        )
        self.latest[sym] = dict(v)
        self._update_state(sym, tick, detect_signal=False)

    def _seed_depth_quote(self, sym, d):
        tr = self.state.get_or_create(sym)
        if not tr.ticks:
            ltp = float(d.get("ltp") or self.latest.get(sym, {}).get("lp") or 0)
            if ltp <= 0:
                return
            tick = Tick(
                time.time(),
                ltp,
                0,
                float(d.get("bid", 0)),
                float(d.get("ask", 0)),
                int(d.get("bid_qty", 0)),
                int(d.get("ask_qty", 0)),
                int(d.get("volume", 0)),
            )
            self._update_state(sym, tick, detect_signal=False)

    def _parse(self, msg, sym=None) -> Optional[Tick]:
        if not isinstance(msg, dict):
            return None
        sym = sym or msg.get("symbol") or msg.get("n")
        if not sym:
            return None

        ltp = self.num(msg, "ltp", "lp")
        ts = self.num(msg, "timestamp", "tt", "exch_feed_time", default=time.time())
        ts = ts / 1000 if ts > 1e10 else ts
        ltq = int(self.num(msg, "ltq", "last_traded_qty", "last_traded_quantity", "ltq_qty"))
        bid = self.num(msg, "bid", "bid_price")
        ask = self.num(msg, "ask", "ask_price")
        bq = int(self.num(msg, "bid_size", "bid_qty", "bid_quantity", "bidqty"))
        aq = int(self.num(msg, "ask_size", "ask_qty", "ask_quantity", "askqty"))
        vol = int(self.num(msg, "vol_traded_today", "volume", "vtt"))

        # DepthUpdate messages can carry arrays/totals rather than flat fields.
        dep = msg.get("depth") or msg.get("d")
        if isinstance(dep, dict):
            normalized = self._depth_fields({"d": dep})
            ltp = normalized.get("ltp", ltp) or ltp
            bid = normalized.get("bid", bid) or bid
            ask = normalized.get("ask", ask) or ask
            bq = normalized.get("bid_qty", bq) or bq
            aq = normalized.get("ask_qty", aq) or aq
            vol = normalized.get("volume", vol) or vol

        if ltp <= 0:
            # Keep LTP from the most recent SymbolUpdate if this is a depth-only message.
            old = self.latest.get(sym, {})
            ltp = self.num(old, "lp", "ltp", default=ltp)
        if ltp <= 0:
            return None
        return Tick(ts, ltp, ltq, bid, ask, bq, aq, vol)

    def _on_message(self, msg):
        if not isinstance(msg, dict):
            return
        sym = msg.get("symbol") or msg.get("n")
        if not sym:
            return
        with self._lock:
            old = self.latest.get(sym, {})
            merged = dict(old)
            merged.update(msg)
            self.latest[sym] = merged

            # Parse full symbol/depth updates. A depth update with no trade fields
            # updates the book in `self.depth` without adding a fake LTQ tick.
            t = self._parse(msg, sym)
            is_depth = "depth" in msg or str(msg.get("type", "")).lower().startswith("depth")
            if is_depth:
                dep = msg.get("depth") or msg.get("d")
                if isinstance(dep, dict):
                    parsed = self._depth_fields({"d": dep})
                    if parsed:
                        self.depth[sym] = parsed
                        self.depth_cache[sym] = (time.time(), parsed)
                # If the message has no executable trade quantity, don't create a
                # duplicate execution tick; the latest SymbolUpdate will carry LTQ.
                if self.num(msg, "ltq", "last_traded_qty", "last_traded_quantity") <= 0 and not self.num(msg, "lp", "ltp"):
                    return
            if t:
                self._update_state(sym, t, detect_signal=True)

    def _update_state(self, sym, tick, detect_signal=True):
        tr = self.state.get_or_create(sym)
        if sym not in self.fast:
            self.fast[sym] = RunningSMMA(cfg.smma_fast)
            self.slow[sym] = RunningSMMA(cfg.smma_slow)
        sf = self.fast[sym].update(tick.ltp)
        ss = self.slow[sym].update(tick.ltp)
        tr.smma_fast = sf
        tr.smma_slow = ss
        self.state.update(sym, tick)
        if sf is None or ss is None:
            return

        diff = sf - ss
        prev = self.prev_diff.get(sym)
        signal = None
        if detect_signal and prev is not None:
            if prev <= 0 < diff:
                signal = "BUY"
            elif prev >= 0 > diff:
                signal = "SELL"
        self.prev_diff[sym] = diff

        if signal:
            tr.last_signal = signal
            tr.signal_ts = tick.ts
            tr.signal_ltp = tick.ltp
            tr.crossover_count += 1
            self.crossover_events.append({"symbol": sym, "signal": signal, "timestamp": tick.ts, "ltp": tick.ltp})
            self.crossover_events = self.crossover_events[-2000:]

    def _connect_websocket(self):
        if self.ws is not None or not self.candidates:
            return
        try:
            self.ws = data_ws.FyersDataSocket(
                access_token=self.token,
                log_path="",
                litemode=False,
                write_to_file=False,
                reconnect=True,
                on_connect=self._on_open,
                on_message=self._on_message,
                on_error=self._on_error,
                on_close=self._on_close,
            )
            self.ws.connect()
        except Exception as exc:
            self.ws = None
            self.ws_connected = False
            self.last_error = f"WebSocket start error: {exc}"

    def _on_open(self, *args, **kwargs):
        try:
            if self.ws and self.candidates:
                self.ws.subscribe(symbols=self.candidates, data_type="SymbolUpdate")
                self.ws.subscribe(symbols=self.candidates, data_type="DepthUpdate")
                self._subscribed_symbols = set(self.candidates)
                self.ws_connected = True
        except Exception as exc:
            self.ws_connected = False
            self.last_error = f"Subscription error: {exc}"

    def _on_error(self, msg):
        self.ws_connected = False
        self.last_error = f"WebSocket error: {msg}"

    def _on_close(self, *args):
        self.ws_connected = False
        self.last_error = f"WebSocket closed: {args}"
        self.ws = None

    def start(self):
        if self.started:
            return
        self.started = True
        # Do a bounded first pass so startup remains responsive. The worker then
        # continues the full 1,144+ symbol depth queue in the background.
        self.initial_screen(depth_batch=self.DEPTH_BATCH_PER_SCAN)
        if self.candidates:
            self._connect_websocket()
        else:
            self.last_error = (
                "DEPTH SCAN IN PROGRESS: no qualified stock found in the first "
                f"{self._depth_scan_checked} checks; remaining candidates continue in background."
            )
        self._start_depth_worker()

    def snapshot(self):
        now = time.time()
        if not self.started:
            self.start()
        elif now - self.last_scan >= cfg.screen_interval and self._depth_scan_complete:
            # Only start a new full price/depth cycle after the previous
            # resumable depth queue has finished. Refreshing the UI never
            # resets an in-progress scan.
            self._price_screen()
            self._queue_depth_scan(force=False)
            self.last_scan = now

        out = []
        with self._lock:
            for sym in self.candidates:
                tr = self.state.trackers.get(sym)
                if not tr or not tr.ticks:
                    continue
                t = tr.ticks[-1]
                if not (cfg.ltp_min <= t.ltp <= cfg.ltp_max and t.bid_qty > cfg.min_bid and t.ask_qty > cfg.min_ask):
                    continue
                w = tr.get_all_windows(now)
                a2 = tr.avg_ltq(2, now)
                a5 = tr.avg_ltq(5, now)
                sig = tr.last_signal if tr.signal_ts and now - tr.signal_ts <= 5 else None
                out.append({
                    "symbol": sym.replace("NSE:", "").replace("-EQ", ""),
                    "raw_symbol": sym,
                    "ltp": t.ltp,
                    "bid": t.bid,
                    "bid_qty": t.bid_qty,
                    "ask": t.ask,
                    "ask_qty": t.ask_qty,
                    "smma_20": tr.smma_fast,
                    "smma_120": tr.smma_slow,
                    "etq_5": w[5].etq,
                    "etq_20": w[20].etq,
                    "etq_60": w[60].etq,
                    "avg_ltp_20": w[20].avg_ltp,
                    "avg_ltp_60": w[60].avg_ltp,
                    "ltq": t.ltq,
                    "volume": t.volume,
                    "ltq_avg_2m": a2,
                    "ltq_avg_5m": a5,
                    "ltq_ratio_2_5": a2 / a5 if a5 else 1,
                    "signal": sig,
                    "_tracker": tr,
                    "_tick": t,
                    "timestamp": t.ts,
                })
        return sorted(out, key=lambda x: x["symbol"])

    def status(self):
        return {
            "service_started": self.started,
            "websocket_connected": self.ws_connected,
            "universe": len(self.universe or []),
            "price_candidates": len(self.price_candidates),
            "liquidity_qualified": len(self.candidates),
            "depth_requests": self.last_depth_requests,
            "depth_checked": self._depth_scan_checked,
            "depth_pending": len(self._depth_queue),
            "depth_scan_complete": self._depth_scan_complete,
            "depth_scan_total": self._depth_scan_total,
            "last_error": self.last_error,
            "last_scan": self.last_scan,
        }

    def stop(self):
        try:
            if self.ws:
                self.ws.close_connection()
        except Exception:
            pass
        self._stop_event.set()
        self.ws = None
        self.ws_connected = False
        self._subscribed_symbols.clear()
        self.started = False
