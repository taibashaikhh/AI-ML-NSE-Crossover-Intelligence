from config import cfg
from data.fyers_provider import FyersProvider
from data.mock_provider import MockProvider

def create_provider():
    if cfg.mode=="mock":return MockProvider()
    if cfg.mode=="fyers":return FyersProvider()
    raise ValueError(f"Unknown SCREENER_MODE={cfg.mode}")
