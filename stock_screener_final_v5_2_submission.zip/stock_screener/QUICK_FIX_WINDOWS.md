# Quick Fix / Run Guide — FYERS Live Version

This version fixes the earlier `0 passed the filter` problem by using the **FYERS Market Depth API** for Bid Quantity and Ask Quantity. The Quotes API does not return those quantities in the quote payload.

## 1. Open PowerShell

```powershell
cd "$HOME\Desktop\stock_screener_final_v4\stock_screener"
```

## 2. Activate the existing virtual environment

```powershell
.\venv\Scripts\Activate.ps1
```

If your prompt already begins with `(venv)`, do not activate it again.

## 3. Install/update dependencies

```powershell
python -m pip install -r requirements.txt
```

## 4. Make sure `.env` exists

Run:

```powershell
Test-Path .env
```

It must return:

```text
True
```

The file must contain your own values. Never paste the secret or token into chat.

```text
SCREENER_MODE=fyers
FYERS_APP_ID=YOUR_APP_ID
FYERS_SECRET=YOUR_SECRET
FYERS_ACCESS_TOKEN=YOUR_DAILY_ACCESS_TOKEN
FYERS_REDIRECT_URI=https://trade.fyers.in/api-login/redirect-uri/index.html
```

## 5. Test FYERS Market Depth first

Run:

```powershell
python debug_fyers_depth.py
```

Expected shape:

```text
Depth status: OK
LTP: ...
Bid price: ...
Bid quantity (total buy): ...
Ask price: ...
Ask quantity (total sell): ...
```

If FYERS returns a permission error, open your FYERS API app settings and make sure **Market Depth** permission is enabled, then generate a fresh daily access token. FYERS documents Market Depth as a separate data permission.

## 6. Run the full connection test

```powershell
python test_fyers_connection.py
```

The important lines are:

```text
[2/6] NSE equity universe: 24xx
[3/6] Price scan: 24xx symbols scanned; N in LTP range ₹30–₹500
[4/6] Liquidity scan: M passed Bid Qty > 1,000,000 AND Ask Qty > 1,000,000
```

`N` and `M` change with live market conditions. They should not be hard-coded.

## 7. Start the dashboard

```powershell
streamlit run dashboard.py
```

Open the local address shown by Streamlit, normally:

```text
http://localhost:8501
```

The dashboard shows:

- Full NSE universe count
- LTP-qualified count
- Depth/liquidity-qualified count
- Live LTP
- Bid/Ask price and quantity
- SMMA 20/120
- ETQ 5/20/60 minutes
- Average LTP 20/60 minutes
- LTQ and LTQ 2m/5m ratio
- BUY/SELL crossover
- ML probability and explanation when a trained real-data model exists

## 8. If you see zero liquidity-qualified stocks

Do **not** lower the assignment limits.

The required filters remain:

- LTP ₹30–₹500
- Bid Quantity > 10,00,000
- Ask Quantity > 10,00,000

Run during NSE equity market hours and first test:

```powershell
python debug_fyers_depth.py
```

If that returns valid quantities, the provider is working. A zero qualifying count can legitimately occur because the depth condition is very restrictive.

## 9. Important FYERS API limitation

The project scans the full NSE universe for price eligibility, but FYERS market-depth REST requests are subject to broker API rate limits. The code throttles depth calls instead of firing thousands of requests at once. The live Data WebSocket is then used for the qualified symbols.

The default live-symbol cap is 200 to stay within the documented Data WebSocket subscription capacity. If more than 200 symbols qualify, the code must be extended with a rotating subscription strategy rather than simply increasing the number and risking dropped data.

## 10. Train the next-day model

After a real trading day has produced enough closed crossover outcomes:

```powershell
python train_previous_day.py
```

The model intentionally refuses to invent/simulate training labels. It trains from stored real crossover outcomes only.

## 11. Build the Windows EXE

Run:

```powershell
build_exe.bat
```

The EXE is built on Windows using PyInstaller. Keep the `.env` file outside the executable and never package credentials inside the EXE.


## v5.2: FYERS depth-rate-limit fix

The live provider does NOT request Market Depth for all LTP-qualified symbols in one burst.
It now:
- screens the complete NSE universe with the Quotes API (50 symbols/request);
- queues every ₹30–₹500 price candidate for depth screening;
- checks depth at a conservative 60 requests/minute;
- checks a bounded first batch at startup;
- continues the remaining depth queue in a background worker;
- prioritizes higher reported daily volume so useful candidates can appear sooner;
- caches recent depth results;
- reports `Depth scan IN PROGRESS` instead of incorrectly treating an incomplete scan as zero;
- never lowers the assignment thresholds (Bid Qty > 1,000,000 and Ask Qty > 1,000,000).

If FYERS reports `request limit reached` from a previous run, stop the program and wait for the broker's rate window to reset. FYERS states that repeatedly exceeding the per-minute limit can lead to access being blocked for the remainder of the day.
