"""Connect crossover events, real outcomes, and next-day model training."""
from __future__ import annotations
from datetime import datetime
import pandas as pd
from data_store import LearningStore
from ml_model import CrossoverPredictor

class LearningManager:
    def __init__(self):
        self.store = LearningStore()
        self.model = CrossoverPredictor()
        self.processed = set()

    def process(self, row, pred):
        sig = row.get("signal")
        if sig not in ("BUY", "SELL"):
            return None
        key = (row["symbol"], sig, float(row["timestamp"]))
        if key in self.processed:
            return None
        self.processed.add(key)
        closed = self.store.close_previous(row["symbol"], row["timestamp"], row["ltp"])
        rid = self.store.add_signal(row, sig, pred)
        return rid, closed

    def train_previous_days(self):
        """Train using only closed real outcomes strictly before today's date."""
        rows = self.store.history(True)
        if not rows:
            return {"status":"no_data","rows":0}
        df = pd.DataFrame(rows)
        today = datetime.now().strftime("%Y-%m-%d")
        prior = df[df.day < today].copy()
        if prior.empty:
            return {"status":"waiting_for_previous_day","rows":0,"today":today}
        return self.model.train_from_history(prior, training_day=str(prior.day.max()))

    def stats(self, day=None):
        return self.store.evaluation(day)
