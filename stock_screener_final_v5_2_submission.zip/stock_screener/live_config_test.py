from config import FYERS_APP_ID,FYERS_ACCESS_TOKEN,FYERS_SECRET,FYERS_REDIRECT_URI
print('FYERS_APP_ID:', 'SET' if FYERS_APP_ID else 'MISSING')
print('FYERS_SECRET:', 'SET' if FYERS_SECRET else 'MISSING')
print('FYERS_ACCESS_TOKEN:', 'SET' if FYERS_ACCESS_TOKEN else 'MISSING')
print('FYERS_REDIRECT_URI:', FYERS_REDIRECT_URI)
print('Never paste secrets/tokens into chat or commit .env.')
