# Windows execution guide

## A. First-time setup

1. Extract the ZIP to Desktop. Open the inner `stock_screener` folder.
2. In File Explorer, click the address bar, type `powershell`, and press Enter.
3. Check Python:

```powershell
python --version
```

Use Python 3.12.x.

4. Create the virtual environment:

```powershell
python -m venv venv
```

5. Activate it:

```powershell
.\venv\Scripts\Activate.ps1
```

If PowerShell blocks scripts:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\venv\Scripts\Activate.ps1
```

6. Install packages:

```powershell
pip install -r requirements.txt
```

## B. Configure FYERS without exposing credentials

1. Copy `.env.example` to `.env`.
2. Open `.env` in Notepad.
3. Enter your own FYERS App ID, Secret and access token.
4. Never send the `.env` contents to anyone and never include `.env` in your submission.

## C. Test the broker connection

Run:

```powershell
python live_config_test.py
python test_fyers_connection.py
```

Run the live test during NSE market hours. A successful test should show an NSE symbol universe, the number of symbols passing the screen, and a WebSocket connection. Outside market hours it may connect but receive no fresh ticks.

## D. Run the dashboard

```powershell
streamlit run dashboard.py
```

Open the Local URL shown by Streamlit, usually `http://localhost:8501`.

The dashboard is paper-trading only. It never submits broker orders.

## E. First real-data day

Keep the dashboard running during the trading session. The program stores every detected crossover and its real market features in:

`data_store/market_learning.db`

The first day intentionally shows `LEARNING` until enough real crossover outcomes have closed. Do not use synthetic accuracy figures in the report.

## F. Train for the next trading day

After the market day has ended and enough opposite crossovers have closed the stored signals:

```powershell
python train_previous_day.py
```

or:

```powershell
python daily_report.py --train
```

The model is saved locally as `models/next_day_mlp.joblib`.

## G. Next trading day

Start the dashboard again:

```powershell
streamlit run dashboard.py
```

The model trained from previous real outcomes will be loaded automatically. New crossovers are scored with the previous-day model. Their eventual outcomes are stored for the next retraining cycle.

## H. Build the Windows executable

Run on Windows:

```powershell
.\build_exe.bat
```

The executable will be created under:

`dist\StockScreener\StockScreener.exe`

Keep the `.env` file outside the source ZIP and outside the public submission package. Put the `.env` beside the executable when running locally if your launcher is configured to load it from that directory.

## I. Screen-recording sequence

1. Show the project folder and source code.
2. Run `streamlit run dashboard.py`.
3. Show the FYERS LIVE DATA indicator.
4. Show the LTP and liquidity filters.
5. Show ETQ 5/20/60 and average LTP 20/60.
6. Show bid/ask and quantities.
7. Show an SMMA 20/120 crossover.
8. Show the AI ACCEPT/AVOID decision and probability.
9. Show the explanation generated from LTQ/order-book/SMMA features.
10. Show the paper-trade result and P&L after the opposite crossover.
11. On a later day, show the AI Learning section with previous-day training and next-day validation metrics.
