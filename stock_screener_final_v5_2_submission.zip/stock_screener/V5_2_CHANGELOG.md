# v5.2 changes

## Critical correctness fixes
- ML-unavailable crossover rows are stored with `ml_accepted = NULL`, not false. They are therefore not counted as ML-avoided signals.
- The analysis panel now explicitly reports total baseline signals, ML-evaluated signals, avoided signals, avoidance rate, avoided losses, loss-capture percentage, accepted wins/losses, accepted win/loss rates, and P/L.
- Baseline-vs-AI+LTQ comparison is displayed so the assignment's "does LTQ improve the strategy?" question can be answered from real data.
- A concrete ML avoidance example is shown after a trained model has evaluated and closed a real crossover.
- Previous-day training uses only closed real outcomes strictly before today's date.
- Neural-network training uses a chronological holdout for validation, then refits the deployable model on all prior real outcomes. No synthetic data is created.

## FYERS depth/live-data improvements
- Price screening remains full NSE and uses batched Quotes requests.
- Depth screening remains throttled and resumable so API limits do not produce a false zero-liquidity result.
- Initial depth work is bounded so dashboard startup does not block for minutes.
- Qualified symbols are synchronized incrementally with the WebSocket instead of reconnecting for every new qualifying stock.
- The active WebSocket limit is configurable up to FYERS' documented symbol capacity; default is 5,000 rather than the old 200 cap.

## Submission integrity
- No credentials are bundled.
- No order-placement API is used.
- No synthetic ML training data is bundled.
- The EXE is built on Windows using the included PyInstaller script; credentials remain in a separate `.env` file.
