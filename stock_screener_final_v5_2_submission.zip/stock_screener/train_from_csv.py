"""Train the crossover model from a labeled CSV instead of synthetic data.

Expected columns are the model features plus `profitable` (0/1).  The CSV may
also contain timestamp; if present, rows are sorted chronologically and split
without shuffling to avoid look-ahead leakage.
"""
from __future__ import annotations
import argparse
import os
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from ml_model import FEATURE_NAMES, MODEL_PATH


def train(path: str):
    df = pd.read_csv(path)
    missing = [c for c in FEATURE_NAMES + ["profitable"] if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if "timestamp" in df.columns:
        df = df.sort_values("timestamp")
    split = max(1, int(len(df) * 0.75))
    train_df, test_df = df.iloc[:split], df.iloc[split:]
    if test_df.empty:
        raise ValueError("Need enough rows for a chronological test set")
    model = RandomForestClassifier(
        n_estimators=350, max_depth=10, min_samples_leaf=8,
        class_weight="balanced", random_state=42, n_jobs=-1,
    )
    model.fit(train_df[FEATURE_NAMES], train_df["profitable"].astype(int))
    proba = model.predict_proba(test_df[FEATURE_NAMES])[:, 1]
    pred = (proba >= 0.55).astype(int)
    metrics = {
        "accuracy": float(accuracy_score(test_df["profitable"], pred)),
        "precision": float(precision_score(test_df["profitable"], pred, zero_division=0)),
        "recall": float(recall_score(test_df["profitable"], pred, zero_division=0)),
        "f1": float(f1_score(test_df["profitable"], pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(test_df["profitable"], proba)) if test_df["profitable"].nunique() > 1 else 0.0,
        "training_source": "historical_csv",
    }
    model._project_metrics = metrics
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print("Saved historical-data model:", MODEL_PATH)
    print(metrics)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    args = ap.parse_args()
    train(args.csv)
