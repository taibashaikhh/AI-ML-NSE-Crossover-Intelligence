# AI/ML NSE Stock Screening & Next-Day Crossover Intelligence

## What it does
- Uses FYERS real-time market data in live mode; mock mode is retained only for offline software testing.
- Loads the current NSE capital-market equity symbol master.
- Screens LTP ₹30–₹500 and requires Bid Qty > 10,00,000 and Ask Qty > 10,00,000.
- Tracks SMMA(20), SMMA(120), LTQ, ETQ 5/20/60 minutes, average LTP 20/60 minutes, spread and order-book imbalance.
- Detects every SMMA crossover before display filtering so crossovers are not silently lost.
- Evaluates every crossover as a hypothetical trade outcome.
- Paper-trades only accepted ML signals; exits on the opposite crossover.
- Stores real crossover observations and outcomes in SQLite.
- Trains a multi-layer neural network from previous real trading-day outcomes and applies it on the next trading day.
- Reports avoidance rate, accepted win rate, losses and P&L.

## Important data note
The project does **not** bundle synthetic ML training data. On the first live day the model will show LEARNING/WAITING. After enough real crossover outcomes are closed and the day ends, run `python train_previous_day.py` before the next session. The dashboard then loads that previous-day model automatically.

## Setup
1. Python 3.12 recommended on Windows.
2. PowerShell in this folder.
3. `python -m venv venv`
4. `.\venv\Scripts\Activate.ps1` (type `./venv/Scripts/Activate.ps1` if copying into another shell)
5. `pip install -r requirements.txt`
6. Copy `.env.example` to `.env` and fill your own FYERS values. Never send credentials in chat or include `.env` in the submission.
7. Run `python test_fyers_connection.py` during NSE market hours.
8. Run `streamlit run dashboard.py`.

## First-day / next-day workflow
- Day 1: collect real-time data and crossover outcomes. ML remains unavailable until enough labeled outcomes exist.
- After Day 1: `python train_previous_day.py`
- Day 2: `streamlit run dashboard.py`; the previous-day neural model is used for live decisions.
- Repeat each trading day.

## EXE
Run `build_exe.bat` on Windows. PyInstaller creates `dist\StockScreener\StockScreener.exe`. The `.env` file must be supplied separately and is never bundled.

## No real orders
The project never calls order-placement APIs. It is a paper-trading/research application.

## FYERS depth-filter fix

The live provider now uses FYERS Quotes for the ₹30–₹500 price screen and the FYERS Market Depth API for the required aggregate Bid Quantity and Ask Quantity filters. The previous implementation incorrectly expected `bid_size`/`ask_size` in the Quotes response, which caused every stock to fail the liquidity test.

Run `python debug_fyers_depth.py` before the full test if you need to verify Market Depth permission.

## v5.2 analysis dashboard additions
The dashboard explicitly separates:
- **SMMA baseline**: every closed crossover treated as a hypothetical trade.
- **AI + LTQ accepted**: only crossovers accepted by the trained neural network.
- **ML avoidance rate**: rejected/evaluated crossover signals.
- **Losses avoided %**: rejected losing baseline crossovers divided by all baseline losses.
- **Accepted win/loss rates** and accepted P/L.

A signal recorded before a trained model exists has `ml_accepted = NULL`, not `0`, so first-day learning data is never falsely reported as an ML avoidance.

## Exact daily workflow for the assignment
1. **Day 1 during market hours:** run the FYERS dashboard and collect real crossover observations. The model may remain unavailable.
2. **After Day 1:** wait until opposite crossovers close the hypothetical trades. Run `python train_previous_day.py`.
3. **Day 2 before/during market hours:** the saved neural network is loaded automatically. Each new crossover gets an ACCEPT/AVOID decision and P(profit).
4. **After Day 2:** the database contains the actual Day-2 outcomes. The dashboard can show avoided losses, accepted win rate, accepted loss rate and baseline-vs-AI performance.
5. Repeat the process. The deployable model is retrained from all closed real outcomes strictly before the current date, with a chronological holdout used for honest validation before refitting on prior-day data.
