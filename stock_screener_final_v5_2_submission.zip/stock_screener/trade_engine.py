from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import Dict,Optional
import time
@dataclass
class Position:
    symbol:str; side:str; entry_time:float; entry_price:float; ml_probability:Optional[float]=None
@dataclass
class ClosedTrade:
    symbol:str; side:str; entry_time:float; exit_time:float; entry_price:float; exit_price:float; pnl:float; pnl_pct:float; result:str; ml_probability:Optional[float]=None
class PaperTradeEngine:
    """Paper trades only. An accepted signal opens a position; every opposite crossover exits it."""
    def __init__(self):self.positions={};self.closed=[]
    def process_crossover(self,symbol,signal,price,ts=None,ml_probability=None,accepted=False):
        ts=ts or time.time();cur=self.positions.get(symbol);closed=None
        if cur and cur.side!=signal:
            pnl=(price-cur.entry_price) if cur.side=="BUY" else (cur.entry_price-price);pct=pnl/cur.entry_price*100
            closed=ClosedTrade(symbol,cur.side,cur.entry_time,ts,cur.entry_price,price,round(pnl,2),round(pct,3),"PROFIT" if pnl>0 else "LOSS" if pnl<0 else "FLAT",cur.ml_probability);self.closed.append(closed);del self.positions[symbol]
        if accepted and symbol not in self.positions:self.positions[symbol]=Position(symbol,signal,ts,price,ml_probability)
        return closed
    def snapshot(self):
        n=len(self.closed);wins=sum(t.pnl>0 for t in self.closed);losses=sum(t.pnl<0 for t in self.closed);pnl=sum(t.pnl for t in self.closed)
        return {"open_positions":len(self.positions),"closed_trades":n,"wins":wins,"losses":losses,"win_rate":wins/n if n else 0,"total_pnl":round(pnl,2),"avg_pnl":round(pnl/n,2) if n else 0}
    def trades_as_dicts(self):return [asdict(t) for t in self.closed]
