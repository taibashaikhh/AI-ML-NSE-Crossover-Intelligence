"""Offline smoke test. It never contacts a broker and never trains a fake model."""
import sys
sys.path.insert(0,'.')
from data.mock_provider import MockProvider
from ml_model import CrossoverPredictor
from trade_engine import PaperTradeEngine
from data_store import LearningStore
p=MockProvider(symbols=['NSE:SBIN-EQ'])
rows=p.snapshot()
assert rows, 'Mock provider returned no row'
r=rows[0]; ml=CrossoverPredictor(load_existing=False); pred=ml.predict(r,'BUY'); engine=PaperTradeEngine(); engine.process_crossover(r['symbol'],'BUY',r['ltp'],r.get('timestamp'),pred.probability,pred.accept)
print('OK: mock provider, indicators, rolling ETQ/LTQ features, ML availability state and paper trading imported successfully.')
print('NOTE: no synthetic model is bundled; live model training requires real closed crossover outcomes.')
