"""Next-day neural-network classifier trained only on real labeled crossovers."""
from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Dict
import joblib, numpy as np, pandas as pd
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.inspection import permutation_importance
from config import cfg, MODEL_DIR

MODEL_PATH = os.path.join(MODEL_DIR, "next_day_mlp.joblib")
FEATURE_NAMES = [
    "ltq_ratio_2_5","ltq_spike_ratio","ltq_avg_2m","ltq_avg_5m","etq_5","etq_20","etq_60",
    "bid_ask_imbalance","directional_imbalance","spread_pct","smma_sep_pct",
    "price_vs_avg20_pct","price_vs_avg60_pct","direction"
]

@dataclass
class Prediction:
    signal: str
    accept: bool
    probability: float
    confidence: str
    reason: str
    features: Dict[str,float]
    available: bool = False

class CrossoverPredictor:
    def __init__(self, load_existing=True):
        self.model=None; self.metrics={}; self.feature_names=FEATURE_NAMES
        self.training_rows=0; self.training_day=""
        if load_existing and os.path.exists(MODEL_PATH):
            try:
                obj=joblib.load(MODEL_PATH)
                self.model=obj.get("model"); self.metrics=obj.get("metrics",{})
                self.training_rows=int(obj.get("training_rows",0)); self.training_day=obj.get("training_day","")
            except Exception:
                self.model=None

    @property
    def available(self):
        return self.model is not None

    def extract_features(self,row,signal):
        bid=float(row.get("bid_qty",0) or 0); ask=float(row.get("ask_qty",0) or 0); total=bid+ask
        imbalance=(bid-ask)/total if total else 0.0; direction=1 if signal=="BUY" else -1
        ltp=float(row.get("ltp",0) or 0); bidp=float(row.get("bid",0) or 0); askp=float(row.get("ask",0) or 0)
        spread=(askp-bidp)/ltp*100 if ltp else 0
        sf=float(row.get("smma_20",0) or 0); ss=float(row.get("smma_120",0) or 0)
        sep=(sf-ss)/ltp*100 if ltp else 0
        a2=float(row.get("ltq_avg_2m",0) or 0); a5=float(row.get("ltq_avg_5m",0) or 0); cur=float(row.get("ltq",0) or 0)
        av20=float(row.get("avg_ltp_20",0) or 0); av60=float(row.get("avg_ltp_60",0) or 0)
        return {
            "ltq_ratio_2_5":a2/a5 if a5 else 1.0,"ltq_spike_ratio":cur/a5 if a5 else 1.0,
            "ltq_avg_2m":a2,"ltq_avg_5m":a5,"etq_5":float(row.get("etq_5",0) or 0),
            "etq_20":float(row.get("etq_20",0) or 0),"etq_60":float(row.get("etq_60",0) or 0),
            "bid_ask_imbalance":imbalance,"directional_imbalance":imbalance*direction,
            "spread_pct":spread,"smma_sep_pct":sep,
            "price_vs_avg20_pct":((ltp-av20)/av20*100 if av20 else 0),
            "price_vs_avg60_pct":((ltp-av60)/av60*100 if av60 else 0),"direction":direction,
        }

    def predict(self,row,signal,threshold=None):
        threshold=cfg.ml_threshold if threshold is None else threshold
        feats=self.extract_features(row,signal)
        if not self.available:
            return Prediction(signal,False,0.5,"Unavailable",
                "ML unavailable: waiting for enough closed, real previous-day crossover outcomes. This signal is not counted as ML-avoided.",feats,False)
        X=pd.DataFrame([feats])[FEATURE_NAMES]
        p=float(self.model.predict_proba(X)[0,1]); accept=p>=threshold
        conf="High" if abs(p-0.5)>=0.25 else "Medium" if abs(p-0.5)>=0.12 else "Low"
        return Prediction(signal,accept,p,conf,self.explain(feats,signal,p,accept),feats,True)

    @staticmethod
    def explain(f,signal,p,accept):
        d=[]; ratio=f["ltq_ratio_2_5"]; spike=f["ltq_spike_ratio"]; di=f["directional_imbalance"]
        d.append(f"LTQ 2m/5m={ratio:.2f}")
        if spike>=1.5:d.append("recent LTQ spike supports participation")
        elif spike<0.8:d.append("recent LTQ is weak")
        if di>0.15:d.append("order-book pressure supports the signal")
        elif di<-0.15:d.append("order-book pressure opposes the signal")
        if f["spread_pct"]>0.25:d.append("spread is relatively wide")
        if f["smma_sep_pct"]*f["direction"]>0:d.append("SMMA separation agrees with signal direction")
        return ("ACCEPT" if accept else "AVOID")+f" — model P(profit)={p:.1%}. "+"; ".join(d)+"."

    @staticmethod
    def _make_model():
        return Pipeline([("scale",StandardScaler()),("mlp",MLPClassifier(
            hidden_layer_sizes=(64,32,16),activation="relu",solver="adam",alpha=0.0005,
            early_stopping=True,validation_fraction=0.2,max_iter=600,random_state=42))])

    def train_from_history(self,df,training_day=""):
        df=df.copy()
        missing=[c for c in FEATURE_NAMES+["profitable"] if c not in df.columns]
        if missing: raise ValueError(f"Missing training columns: {missing}")
        df=df.dropna(subset=FEATURE_NAMES+["profitable"])
        df=df.sort_values("timestamp") if "timestamp" in df.columns else df
        if len(df)<cfg.min_train_rows or df.profitable.nunique()<2:
            return {"status":"insufficient_data","rows":len(df),"classes":int(df.profitable.nunique())}

        # Chronological holdout: never use future outcomes to validate past outcomes.
        split=max(int(len(df)*0.75), 1)
        train=df.iloc[:split]; test=df.iloc[split:]
        if len(test)<2 or test.profitable.nunique()<2:
            return {"status":"insufficient_test_classes","rows":len(df),"test_rows":len(test),"classes":int(test.profitable.nunique())}

        eval_model=self._make_model()
        eval_model.fit(train[FEATURE_NAMES],train.profitable.astype(int))
        p=eval_model.predict_proba(test[FEATURE_NAMES])[:,1]; pred=(p>=cfg.ml_threshold).astype(int); y=test.profitable.astype(int)
        metrics={
            "status":"trained","rows":len(df),"train_rows":len(train),"test_rows":len(test),
            "accuracy":accuracy_score(y,pred),"precision":precision_score(y,pred,zero_division=0),
            "recall":recall_score(y,pred,zero_division=0),"f1":f1_score(y,pred,zero_division=0),
            "roc_auc":roc_auc_score(y,p) if y.nunique()>1 else 0.0,"training_day":training_day,
        }

        # Refit the deployable model on ALL prior-day outcomes after honest holdout evaluation.
        deploy_model=self._make_model(); deploy_model.fit(df[FEATURE_NAMES],df.profitable.astype(int))
        self.model=deploy_model
        self.metrics={k:float(v) if isinstance(v,(np.floating,np.integer)) else v for k,v in metrics.items()}
        self.training_rows=len(df); self.training_day=training_day
        os.makedirs(MODEL_DIR,exist_ok=True)
        joblib.dump({"model":deploy_model,"metrics":self.metrics,"training_rows":self.training_rows,"training_day":training_day},MODEL_PATH)
        return self.metrics

    def permutation_importance(self,df):
        if not self.available or df.empty:return pd.Series(dtype=float)
        df=df.dropna(subset=FEATURE_NAMES+["profitable"])
        if df.profitable.nunique()<2:return pd.Series(dtype=float)
        r=permutation_importance(self.model,df[FEATURE_NAMES],df.profitable.astype(int),n_repeats=3,random_state=42,scoring="roc_auc")
        return pd.Series(r.importances_mean,index=FEATURE_NAMES).sort_values()
