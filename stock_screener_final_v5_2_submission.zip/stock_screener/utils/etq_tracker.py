from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from typing import Deque, Dict, List, Optional, Tuple
import time

@dataclass
class Tick:
    ts: float
    ltp: float
    ltq: int
    bid: float = 0.0
    ask: float = 0.0
    bid_qty: int = 0
    ask_qty: int = 0
    volume: int = 0

@dataclass
class WindowStats:
    etq: int = 0
    avg_ltp: float = 0.0
    tick_count: int = 0
    last_ltq: int = 0

class SymbolTracker:
    def __init__(self, windows_min: List[int] = (5,20,60)):
        self.windows=sorted(windows_min); self.max_sec=max(self.windows)*60+60
        self.ticks: Deque[Tick]=deque(); self.ltq_history: Deque[Tuple[float,int]]=deque(maxlen=6000)
        self.smma_fast=None; self.smma_slow=None; self.prev_diff=None
        self.last_signal=None; self.signal_ts=None; self.signal_ltp=None; self.crossover_count=0
    def add_tick(self,tick:Tick):
        self.ticks.append(tick); self.ltq_history.append((tick.ts,int(tick.ltq))); self._prune(tick.ts)
    def _prune(self,now):
        cutoff=now-self.max_sec
        while self.ticks and self.ticks[0].ts < cutoff: self.ticks.popleft()
        cutoff2=now-5*60-5
        while self.ltq_history and self.ltq_history[0][0] < cutoff2: self.ltq_history.popleft()
    def get_window_stats(self,minutes,now=None):
        now=now or time.time(); cutoff=now-minutes*60; qty=0; ps=0; n=0; last=0
        for t in reversed(self.ticks):
            if t.ts<cutoff: break
            qty += max(0,int(t.ltq)); ps += t.ltp; n += 1
            if last==0: last=t.ltq
        return WindowStats(qty, ps/n if n else 0.0, n, last)
    def get_all_windows(self,now=None): return {m:self.get_window_stats(m,now) for m in self.windows}
    def avg_ltq(self,minutes,now=None):
        now=now or time.time(); cutoff=now-minutes*60; vals=[q for ts,q in self.ltq_history if ts>=cutoff]
        return sum(vals)/len(vals) if vals else 0.0
    def ltq_ratio(self,a=2,b=5):
        x,y=self.avg_ltq(a),self.avg_ltq(b); return x/y if y else 1.0

class MarketState:
    def __init__(self,windows_min=(5,20,60)): self.trackers={}; self.windows=windows_min; self.last_update=0
    def get_or_create(self,symbol):
        if symbol not in self.trackers: self.trackers[symbol]=SymbolTracker(self.windows)
        return self.trackers[symbol]
    def update(self,symbol,tick): self.get_or_create(symbol).add_tick(tick); self.last_update=tick.ts
