"""
SMMA (Smoothed Moving Average) implementation and crossover detection.
Formula (Wilder's / TradingView style):
  First value = SMA of first `length` prices
  Subsequent = (prev_smma * (length - 1) + price) / length
"""

from __future__ import annotations
from collections import deque
from typing import Deque, List, Optional, Tuple
import numpy as np
import pandas as pd


def calculate_smma(prices: List[float] | np.ndarray | pd.Series, length: int) -> List[Optional[float]]:
    """Return list of SMMA values aligned with input prices. Leading Nones until first full window."""
    if length < 1:
        raise ValueError("length must be >= 1")
    n = len(prices)
    if n == 0:
        return []
    smma: List[Optional[float]] = [None] * n
    if n < length:
        return smma

    # First SMMA = SMA of first `length` values
    window_sum = sum(float(prices[i]) for i in range(length))
    smma[length - 1] = window_sum / length

    for i in range(length, n):
        prev = smma[i - 1]
        if prev is None:
            continue
        smma[i] = (prev * (length - 1) + float(prices[i])) / length
    return smma


def smma_series(close: pd.Series, length: int) -> pd.Series:
    """Pandas-friendly SMMA."""
    values = calculate_smma(close.values, length)
    return pd.Series(values, index=close.index, name=f"SMMA_{length}")


class RunningSMMA:
    """Incremental SMMA for real-time tick updates."""

    def __init__(self, length: int):
        self.length = length
        self.values: Deque[float] = deque(maxlen=length)  # only needed for initial SMA
        self.smma: Optional[float] = None
        self.count = 0

    def update(self, price: float) -> Optional[float]:
        self.count += 1
        price = float(price)
        if self.smma is None:
            self.values.append(price)
            if len(self.values) == self.length:
                self.smma = sum(self.values) / self.length
            return self.smma
        else:
            self.smma = (self.smma * (self.length - 1) + price) / self.length
            return self.smma

    def reset(self):
        self.values.clear()
        self.smma = None
        self.count = 0


def detect_crossover(
    fast: List[Optional[float]] | np.ndarray,
    slow: List[Optional[float]] | np.ndarray,
) -> List[Optional[str]]:
    """
    Returns list of signals aligned with series:
      "BUY"  when fast crosses above slow
      "SELL" when fast crosses below slow
      None otherwise
    """
    n = min(len(fast), len(slow))
    signals: List[Optional[str]] = [None] * n
    for i in range(1, n):
        f0, s0 = fast[i - 1], slow[i - 1]
        f1, s1 = fast[i], slow[i]
        if None in (f0, s0, f1, s1):
            continue
        if f0 <= s0 and f1 > s1:
            signals[i] = "BUY"
        elif f0 >= s0 and f1 < s1:
            signals[i] = "SELL"
    return signals


def latest_crossover(
    fast_hist: List[Optional[float]],
    slow_hist: List[Optional[float]],
    lookback: int = 5,
) -> Optional[Tuple[str, int]]:
    """Return (signal, bars_ago) of the most recent crossover within lookback, or None."""
    signals = detect_crossover(fast_hist, slow_hist)
    for i in range(len(signals) - 1, max(-1, len(signals) - 1 - lookback), -1):
        if signals[i]:
            return signals[i], len(signals) - 1 - i
    return None
