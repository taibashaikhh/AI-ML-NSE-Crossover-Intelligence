from learning import LearningManager
from pprint import pprint

if __name__ == "__main__":
    pprint(LearningManager().train_previous_days())
