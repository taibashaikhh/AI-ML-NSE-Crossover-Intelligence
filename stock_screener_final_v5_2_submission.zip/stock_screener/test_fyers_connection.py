"""Safe FYERS live-data test. Data-only: never places an order."""
import time
from config import FYERS_APP_ID, FYERS_ACCESS_TOKEN, cfg
from data.fyers_provider import FyersProvider

if __name__ == "__main__":
    print("[1/6] Credentials:", "OK" if FYERS_APP_ID and FYERS_ACCESS_TOKEN else "MISSING")
    p = FyersProvider()
    symbols = p.load_universe(refresh=True)
    print(f"[2/6] NSE equity universe: {len(symbols)}")

    # Start performs a bounded depth batch, then continues the full depth scan
    # in a background worker. This avoids hitting FYERS request limits.
    p.start()
    print(
        f"[3/6] Price scan: {len(p.price_candidates)} stocks currently in "
        f"LTP range ₹{cfg.ltp_min:.0f}–₹{cfg.ltp_max:.0f}"
    )
    print(
        f"[4/6] Depth scan: checked {p._depth_scan_checked} / "
        f"{p._depth_scan_total}; qualified {len(p.candidates)}; "
        f"pending {len(p._depth_queue)}"
    )

    if p.candidates:
        print("[5/6] Live WebSocket: starting for qualified symbols...")
    else:
        print("[5/6] Live WebSocket: waiting while the throttled depth scan continues...")

    time.sleep(5)
    status = p.status()
    print("[6/6] Status:", status)
    if status["depth_scan_complete"]:
        print("Depth scan complete. Zero qualified means zero stocks PASSED the actual depth filter at this scan time.")
    else:
        print(
            "Depth scan is IN PROGRESS. A zero qualified count is NOT a final result yet; "
            f"{status['depth_pending']} price-qualified symbols remain."
        )
    p.stop()
