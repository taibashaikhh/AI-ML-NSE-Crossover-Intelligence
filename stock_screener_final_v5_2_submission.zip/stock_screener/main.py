#!/usr/bin/env python3
from __future__ import annotations
import argparse,time
from rich.console import Console
from rich.live import Live
from rich.table import Table
from config import cfg
from data.provider_factory import create_provider
from learning import LearningManager
from trade_engine import PaperTradeEngine
console=Console()
def table(rows,ml,engine):
 t=Table(title=f"AI/ML NSE Screener — {cfg.mode.upper()} / PAPER TRADING",expand=True)
 for c in ['Symbol','LTP','SMMA20','SMMA120','ETQ5','ETQ20','LTQ 2/5','Signal','ML','P(profit)']:t.add_column(c)
 for r in rows:
  p=ml.predict(r,r['signal']) if r.get('signal') else None
  t.add_row(r['symbol'],f"₹{r['ltp']:.2f}",f"{r['smma_20']:.2f}" if r['smma_20'] else '—',f"{r['smma_120']:.2f}" if r['smma_120'] else '—',f"{r['etq_5']/1e3:.0f}K",f"{r['etq_20']/1e3:.0f}K",f"{r['ltq_ratio_2_5']:.2f}",r.get('signal') or '—',('ACCEPT' if p and p.accept else 'AVOID' if p else 'WAIT'),f"{p.probability:.0%}" if p else '—')
 return t
def run(duration=0):
 p=create_provider();lm=LearningManager();lm.train_previous_days();engine=PaperTradeEngine();start=time.time()
 with Live(console=console,refresh_per_second=2) as live:
  while True:
   rows=p.snapshot()
   for r in rows:
    if r.get('signal'):
     pred=lm.model.predict(r,r['signal']); result=lm.process(r,pred); engine.process_crossover(r['symbol'],r['signal'],r['ltp'],r['timestamp'],pred.probability,pred.accept)
   live.update(table(rows,lm.model,engine))
   if duration and time.time()-start>=duration:break
   time.sleep(cfg.refresh)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--duration',type=int,default=0);ap.add_argument('--train-previous-day',action='store_true');a=ap.parse_args()
 if a.train_previous_day:
  print(LearningManager().train_previous_days())
 else:
  try:run(a.duration)
  except KeyboardInterrupt:print('\nStopped.')
if __name__=='__main__':main()
